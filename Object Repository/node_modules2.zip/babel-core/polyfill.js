module.exports = require("./lib/polyfill");

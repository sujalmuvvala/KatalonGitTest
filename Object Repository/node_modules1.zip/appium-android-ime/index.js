"use strict";

var path = require('path');

module.exports = {
  path: path.resolve(__dirname, "bin", "UnicodeIME-debug.apk")
};

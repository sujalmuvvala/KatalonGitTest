"use strict";

var path = require('path');

module.exports = {
  path: path.resolve(__dirname, "bin", "unlock_apk-debug.apk")
};

// transpile:main

import UiAutomator from './lib/uiautomator';

export default UiAutomator;

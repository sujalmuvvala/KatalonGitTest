appium-fake-driver
===================

Issues for this repo are disabled. Log any issues at the [main Appium repo's issue tracker](https://github.com/appium/appium/issues).

Work in progress, stay tuned!

## Watch

```
npm run watch
```

## Test

```
npm test
```

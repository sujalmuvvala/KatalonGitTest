import { default as chromedriver } from './lib/chromedriver';

export default chromedriver;
